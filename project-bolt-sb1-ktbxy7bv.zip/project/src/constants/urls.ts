// Centralize URLs to make maintenance easier
export const CALENDLY_URL = 'https://calendly.com/niahai';
export const DASHBOARD_IMAGE_URL = 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80';
export const HERO_IMAGE_URL = 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&q=80';