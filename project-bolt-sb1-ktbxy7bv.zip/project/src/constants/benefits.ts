export const benefits = [
  'Improve Patient Retention',
  'Reduce No-Shows by 30%',
  'Automate Administrative Tasks',
  'Better Reporting and Analytics',
  'Grow Your Practice and Attract More Patients'
];